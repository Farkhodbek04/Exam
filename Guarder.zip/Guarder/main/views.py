from django.shortcuts import render

# HTML files

def index(request):

    return render(request, 'front/index.html')

def about(request):

    return render(request, 'front/about.html')

def contact(request):

    return render(request, 'front/contact.html')

def guard(request):

    return render(request, 'front/guard.html')

def service(request):
    
    return render(request, 'front/service.html')


